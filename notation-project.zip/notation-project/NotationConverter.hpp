
#ifndef NOTATIONCONVERTER_HPP
#define NOTATIONCONVERTER_HPP

#include "NotationConverterInterface.hpp"
#include "Deque.hpp"
#include <string>
#include <sstream>
#include <stdexcept>  // for std::invalid_argument

// Class NotationConverter implements the NotationConverterInterface
// It provides methods to convert between postfix, infix, and prefix notations
class NotationConverter : public NotationConverterInterface {
public:
    // Convert postfix notation to infix notation
    std::string postfixToInfix(std::string inStr) override;
    
    // Convert postfix notation to prefix notation
    std::string postfixToPrefix(std::string inStr) override;
    
    // Convert infix notation to postfix notation
    std::string infixToPostfix(std::string inStr) override;
    
    // Convert infix notation to prefix notation
    std::string infixToPrefix(std::string inStr) override;
    
    // Convert prefix notation to infix notation
    std::string prefixToInfix(std::string inStr) override;
    
    // Convert prefix notation to postfix notation
    std::string prefixToPostfix(std::string inStr) override;

private:
    // Utility functions

    // Check if a character is an operator
    bool isOperator(char c);
    
    // Get the precedence of an operator
    int precedence(char op);
    
    // Clean up input string (e.g., remove extra spaces)
    std::string cleanInput(std::string input);

    // Validate the input expression
    bool isValidExpression(const std::string& str);
};

#endif // NOTATIONCONVERTER_HPP
