//tameem tantawy
//U93641744
//Steven Abdalla
//U67196743


#include "NotationConverter.hpp"
#include <stack>
#include <algorithm>
#include <cctype>  // For isalpha, isdigit, etc.
#include <stdexcept>  // For std::invalid_argument

// Helper function to check if a character is an operator
bool NotationConverter::isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Helper function to get precedence of operators
int NotationConverter::precedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

// Helper function to validate the expression
bool NotationConverter::isValidExpression(const std::string& str) {
    for (char c : str) {
        if (!isalpha(c) && !isspace(c) && c != '+' && c != '-' && c != '*' && c != '/' && c != '(' && c != ')') {
            return false;  // Invalid character found
        }
    }
    return true;  // All characters are valid
}

// Postfix to Infix conversion
std::string NotationConverter::postfixToInfix(std::string inStr) {
    if (!isValidExpression(inStr)) {
        throw std::invalid_argument("Invalid characters in expression");
    }

    Deque<std::string> deque;
    std::istringstream iss(inStr);
    std::string token;
    
    while (iss >> token) {
        if (!isOperator(token[0])) {
            // Operand, push to deque
            deque.push_back(token);
        } else {
            // Operator, pop two operands and combine them
            std::string operand2 = deque.pop_back();
            std::string operand1 = deque.pop_back();
            std::string result = "(" + operand1 + " " + token + " " + operand2 + ")";
            deque.push_back(result);
        }
    }
    
    return deque.pop_back();  // Final infix expression
}

// Postfix to Prefix conversion
std::string NotationConverter::postfixToPrefix(std::string inStr) {
    if (!isValidExpression(inStr)) {
        throw std::invalid_argument("Invalid characters in expression");
    }

    // Convert postfix to infix, then infix to prefix
    std::string infix = postfixToInfix(inStr);
    return infixToPrefix(infix);
}

// Infix to Postfix conversion
std::string NotationConverter::infixToPostfix(std::string inStr) {
    if (!isValidExpression(inStr)) {
        throw std::invalid_argument("Invalid characters in expression");
    }

    Deque<char> operatorDeque;
    std::stringstream output;
    std::istringstream iss(inStr);
    char token;

    while (iss >> token) {
        if (isalnum(token)) {
            // Operand, output it
            output << token << ' ';
        } else if (token == '(') {
            operatorDeque.push_back(token);
        } else if (token == ')') {
            // Pop until matching '('
            while (!operatorDeque.is_empty() && operatorDeque.peek_back() != '(') {
                output << operatorDeque.pop_back() << ' ';
            }
            operatorDeque.pop_back();  // Pop the '('
        } else if (isOperator(token)) {
            while (!operatorDeque.is_empty() && precedence(operatorDeque.peek_back()) >= precedence(token)) {
                output << operatorDeque.pop_back() << ' ';
            }
            operatorDeque.push_back(token);
        }
    }
    
    // Pop any remaining operators
    while (!operatorDeque.is_empty()) {
        output << operatorDeque.pop_back() << ' ';
    }

    return output.str();
}

// Infix to Prefix conversion
std::string NotationConverter::infixToPrefix(std::string inStr) {
    if (!isValidExpression(inStr)) {
        throw std::invalid_argument("Invalid characters in expression");
    }

    // Reverse infix, convert to postfix, then reverse result
    std::reverse(inStr.begin(), inStr.end());
    for (char &c : inStr) {
        if (c == '(') c = ')';
        else if (c == ')') c = '(';
    }

    std::string postfix = infixToPostfix(inStr);
    std::reverse(postfix.begin(), postfix.end());

    return postfix;
}

// Prefix to Infix conversion
std::string NotationConverter::prefixToInfix(std::string inStr) {
    if (!isValidExpression(inStr)) {
        throw std::invalid_argument("Invalid characters in expression");
    }

    Deque<std::string> deque;
    std::istringstream iss(inStr);
    std::string token;

    // Read from right to left for prefix
    std::vector<std::string> tokens;
    while (iss >> token) {
        tokens.push_back(token);
    }

    for (auto it = tokens.rbegin(); it != tokens.rend(); ++it) {
        if (!isOperator((*it)[0])) {
            // Operand, push to deque
            deque.push_back(*it);
        } else {
            // Operator, pop two operands and combine them
            std::string operand1 = deque.pop_back();
            std::string operand2 = deque.pop_back();
            std::string result = "(" + operand1 + " " + *it + " " + operand2 + ")";
            deque.push_back(result);
        }
    }
    
    return deque.pop_back();
}

// Prefix to Postfix conversion
std::string NotationConverter::prefixToPostfix(std::string inStr) {
    if (!isValidExpression(inStr)) {
        throw std::invalid_argument("Invalid characters in expression");
    }

    // Convert prefix to infix, then infix to postfix
    std::string infix = prefixToInfix(inStr);
    return infixToPostfix(infix);
}
