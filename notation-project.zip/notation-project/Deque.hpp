
#ifndef DEQUE_HPP
#define DEQUE_HPP

#include <stdexcept>  // for exceptions

// Template class Deque implements a double-ended queue data structure
template <typename T>
class Deque {
private:
    // Node structure for the doubly linked list
    struct Node {
        T data;
        Node* next;
        Node* prev;
        Node(T value) : data(value), next(nullptr), prev(nullptr) {}
    };
    Node* head;  // Pointer to the front of the deque
    Node* tail;  // Pointer to the back of the deque
    int size;    // Number of elements in the deque

public:
    // Constructor: Initialize an empty deque
    Deque() : head(nullptr), tail(nullptr), size(0) {}

    // Destructor: Clean up all nodes in the deque
    ~Deque() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

    // Add an element to the front of the deque
    void push_front(T value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        size++;
    }

    // Add an element to the back of the deque
    void push_back(T value) {
        Node* newNode = new Node(value);
        if (tail == nullptr) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        size++;
    }

    // Remove and return the front element of the deque
    T pop_front() {
        if (size == 0) throw std::out_of_range("Deque is empty");
        Node* temp = head;
        T value = head->data;
        head = head->next;
        if (head != nullptr) {
            head->prev = nullptr;
        } else {
            tail = nullptr;
        }
        delete temp;
        size--;
        return value;
    }

    // Remove and return the back element of the deque
    T pop_back() {
        if (size == 0) throw std::out_of_range("Deque is empty");
        Node* temp = tail;
        T value = tail->data;
        tail = tail->prev;
        if (tail != nullptr) {
            tail->next = nullptr;
        } else {
            head = nullptr;
        }
        delete temp;
        size--;
        return value;
    }

    // Return the front element without removing it
    T peek_front() const {
        if (size == 0) throw std::out_of_range("Deque is empty");
        return head->data;
    }

    // Return the back element without removing it
    T peek_back() const {
        if (size == 0) throw std::out_of_range("Deque is empty");
        return tail->data;
    }

    // Check if the deque is empty
    bool is_empty() const {
        return size == 0;
    }

    // Return the number of elements in the deque
    int get_size() const {
        return size;
    }
};

#endif // DEQUE_HPP
